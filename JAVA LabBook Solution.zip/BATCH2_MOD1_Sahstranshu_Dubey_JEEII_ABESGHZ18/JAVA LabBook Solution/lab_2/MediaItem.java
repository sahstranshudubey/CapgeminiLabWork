package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public abstract class MediaItem extends Item {
	
	private int runTime;

	@Override
	public int hashCode() {
		return runTime;
	}

	public MediaItem(int runTime) {
		super();
		this.runTime = runTime;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		MediaItem other = (MediaItem) obj;
		if (runTime != other.runTime)
			return false;
		return true;
	}

	public int getRunTime() {
		return runTime;
	}


}
