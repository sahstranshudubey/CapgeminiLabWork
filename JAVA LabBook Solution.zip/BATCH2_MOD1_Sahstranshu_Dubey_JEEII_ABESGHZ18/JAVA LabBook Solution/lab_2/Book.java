package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public class Book extends WrittenItem {
	
	public Book(String author) {
		super(author);
	}
	

}
