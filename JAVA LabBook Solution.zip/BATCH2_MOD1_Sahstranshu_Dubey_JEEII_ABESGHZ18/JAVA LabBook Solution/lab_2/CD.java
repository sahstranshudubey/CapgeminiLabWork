package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public class CD extends MediaItem {
	private String Artist;
	private String genre;

	public CD(int runTime, String artist, String genre) {
		super(runTime);
		Artist = artist;
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "CD [Artist=" + Artist + ", genre=" + genre + "]";
	}

	public CD(int runTime) {
		super(runTime);
	}

	public String getArtist() {
		return Artist;
	}

	public void setArtist(String artist) {
		Artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

}
