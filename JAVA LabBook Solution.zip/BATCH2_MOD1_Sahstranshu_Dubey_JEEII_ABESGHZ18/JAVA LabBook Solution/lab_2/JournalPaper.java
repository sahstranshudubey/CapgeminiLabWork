package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public class JournalPaper extends WrittenItem{
	
	public JournalPaper(String author) {
		super(author);
	}

}
