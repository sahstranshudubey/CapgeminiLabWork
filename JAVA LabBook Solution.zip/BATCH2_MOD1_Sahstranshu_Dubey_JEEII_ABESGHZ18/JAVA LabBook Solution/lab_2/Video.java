package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public abstract class Video extends MediaItem{
	
	private String director;
	private String genre;
	private int year;
	
	public Video(int runTime, String director, String genre, int year) {
		super(runTime);
		this.director = director;
		this.genre = genre;
		this.year = year;
	}

	@Override
	public String toString() {
		return "Video [director=" + director + ", genre=" + genre + ", year=" + year + "]";
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Video(int runTime) {
		super(runTime);
	}



}
