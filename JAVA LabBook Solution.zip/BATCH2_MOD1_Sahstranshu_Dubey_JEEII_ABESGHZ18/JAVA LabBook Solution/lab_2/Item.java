package lab_2;
/**
 * 
 * @author sahstranshu
 *
 */
public abstract class Item {
	private String idNo;
	private String  title;
	private int noOfCopies;
	
	public String getIdno() {
		return idNo;
	}
	public void setIdno(String idno) {
		this.idNo = idno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	@Override
	public int hashCode() {
		return idNo.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (idNo == null) {
			if (other.idNo != null)
				return false;
		} else if (!idNo.equals(other.idNo))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Item [idno=" + idNo + ", title=" + title + ", noOfCopies=" + noOfCopies + "]";
	}
}
