package Lab6.exercise3;

public class MirrorImageMain {
	public static void main(String[] args) {
		MirrorImage obj=new MirrorImage();
		System.out.println(obj.mirror());
		}

}
