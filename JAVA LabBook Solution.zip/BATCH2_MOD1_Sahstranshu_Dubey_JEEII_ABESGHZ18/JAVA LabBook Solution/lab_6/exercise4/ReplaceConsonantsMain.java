package Lab6.exercise4;

public class ReplaceConsonantsMain {
	public static void main(String[] args) {
		
		ReplaceConsonants obj=new ReplaceConsonants();
		System.out.println(obj.replace());
	}
}
