package lab_1;

import java.util.Scanner;

public class IsIncreasingNumber {
	public static boolean checkNumber(int n) {
		while(n!=0) {
			int a=n%10;
			n=n/10;
			int b=n%10;
			if(b>a)
				return false;
			
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner input= new Scanner(System.in);
		n=input.nextInt();
		System.out.println(checkNumber(n));
		

	}

}
