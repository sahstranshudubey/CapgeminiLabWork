package lab_1;

import java.util.Scanner;

public class Sum1 {
	public static int calculateDifference(int n) {
		int sum1,sum2;
		sum1= n*(n+1)*(2*n+1)/6 ;
		sum2=n*(n+1)/2;
		return sum1-sum2;
		
	}
public static void main(String[]args) {
	
	int n;
	System.out.println("-----enter the no.-----");
	
	Scanner input=new Scanner(System.in);
	n=input.nextInt();
	int difference=calculateDifference(n);
	System.out.println("difference is ---> "+difference);
	
}

}
