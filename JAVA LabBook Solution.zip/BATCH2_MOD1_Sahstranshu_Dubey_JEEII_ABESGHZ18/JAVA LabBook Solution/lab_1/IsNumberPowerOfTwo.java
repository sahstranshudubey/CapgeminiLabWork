package lab_1;
import java.util.Scanner;

public class IsNumberPowerOfTwo {
	public static boolean checkNumber(int n) {
		while(n!=1) {
		int a=n%2;
		n=n/2;
		if(a!=0)
			return false;		
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner input=new Scanner(System.in);
		n=input.nextInt();
		System.out.println(checkNumber(n));

	}

}
