package lab_1;

import java.util.Scanner;

public class Sum {
	public static  int calculateSum(int n)
	{
		int sum = 0;
		
		for(int i=1;i<=n;i++) {
			if((i%3==0) && (i%5==0)) {
				sum=sum+i;
			}
		}
		//sum=n*(n+1)/2;
		return sum;
	}


public static void main(String[]args) {
	int n;
	System.out.println("-----enter the no. upto u have to calculate the sum-----");
	Scanner input=new Scanner(System.in);
	n=input.nextInt();
	
	n=calculateSum(n);
	System.out.println("sum---> "+n);
	
}
}
