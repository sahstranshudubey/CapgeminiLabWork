package lab_3;

import java.lang.Integer;
import java.util.Arrays;
import java.util.Scanner;

/**
 * 
 * @author sahstranshu
 *
 */
public class IntegerArray {
	/**
	 * 
	 * @param intArr
	 * @return
	 */

	public static int[] integerArray(int intArr[]) {
		for (int i = 0; i < intArr.length; i++) {
			intArr[i] = (int) Integer.reverse(intArr[i]);
			System.out.println(intArr[i]);
		}
		Arrays.sort(intArr);
		System.out.println("done");
		return intArr;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		int[] a;
		int n;
		Scanner input = new Scanner(System.in);
		System.out.println("enter the number of numbers--> ");
		n = input.nextInt();
		int intArr[] = new int[n];
		/**
		 * taking input
		 */
		for (int i = 0; i < n; i++) {
			int c = input.nextInt();
			intArr[i] = c;
		}
		a = integerArray(intArr);
		System.out.println("output array is--> " + Arrays.toString(a));

	}

}
