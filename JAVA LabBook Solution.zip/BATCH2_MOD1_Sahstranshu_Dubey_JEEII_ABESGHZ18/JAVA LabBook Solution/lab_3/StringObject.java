package lab_3;
import java.util.*;
import java.util.Arrays;
import java.util.Scanner;
/**
 * 
 * @author sahstranshu
 *
 */

public class StringObject {
	/**
	 * 
	 * @param stringArray
	 */
	public static void sortInAlphabeticalorder(String stringArray[]) {
	/**
	 * sorting string array according to alphabetical order
	 */
	for(int i=0; i<stringArray.length;i++) {
		for(int j=i+1;j<stringArray.length;j++){
			/**
			 * comparing
			 */
			if((stringArray[i].compareTo(stringArray[j]))>0)
			{
				String temp=stringArray[i];
				stringArray[i]=stringArray[j];
				stringArray[j]=temp;
				
			}
		}
	}
	/**
	 * printing half in capital letters
	 */
	if((stringArray.length)!=0) {
		for(int i=0;i<(1+stringArray.length/2);i++) {
			
			stringArray[i]=stringArray[i].toUpperCase();
			
	}
	}
	
	}
	/**
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		/**
		 * variable initialisation
		 */
		String stringArray[]= new String[5];
		Scanner input=new Scanner(System.in);
		System.out.println("enter no. of strings have to be sorted--> ");
		int count=input.nextInt();
		System.out.println("enter the strings ");
		/**
		 * taking input from user 
		 */
		
		for(int i=0;i<count;i++) {
			stringArray[i]=input.next();
			input.nextLine();
							
		}
		/**
		 * printing the user input string
		 */
		
		System.out.println("Stirngs given: "+ Arrays.toString(stringArray));
		sortInAlphabeticalorder(stringArray);   //sorting method call
		System.out.println("Stirngs in sorted Order: "+ Arrays.toString(stringArray)); // printing shorted array
	}

}

