package lab_3;

import java.util.Arrays;

/**
 * 
 * @author sahstranshu
 *
 */

public class SecondNumber {
	/**
	 * 
	 * @param intArr
	 * @return
	 */
	public static int getSecondSmallestNumber(int intArr[]) {
		for (int i = 0; i <= intArr.length; i++) {
			for (int j = i + 1; j < intArr.length; j++) {
				if (intArr[i] > intArr[j]) {
					int t;
					t = intArr[i];
					intArr[i] = intArr[j];
					intArr[j] = t;
				}

			}
		}
		return intArr[1];
	}
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n, intArr[] = { 10, 50, 1, 40, 25, 30, 2 };
		n = getSecondSmallestNumber(intArr);
		System.out.println("second smallest no.-->> " + n);
	}

}
